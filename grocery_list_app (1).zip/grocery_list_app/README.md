# Grocery List App

A complete offline grocery list application built with Flutter, featuring modern Material 3 design, Hive database for local storage, and comprehensive state management with Riverpod.

## Features

### 🏠 Core Functionality
- **11 Complete Screens**: Home, List Detail, Add/Edit Item, Category Management, Search/Filter, Statistics, Settings, Backup/Restore, Schedule, and more
- **Offline-First**: All data stored locally using Hive database
- **Material 3 Design**: Modern, clean UI with dynamic theming
- **Dark/Light Mode**: System-aware theme switching

### 📱 Screen Overview

1. **Home Screen**: Display all grocery lists with title, item count, and completion badges
2. **List Detail Screen**: Show items with checkbox toggle, swipe to delete, and item status
3. **Add Item Screen**: Form with item name, quantity, category dropdown, and notes
4. **Edit Item Screen**: Update any grocery item details
5. **Category Management**: Add, edit, delete item categories with color coding
6. **Search & Filter**: Global search with filtering by status and category
7. **Statistics Screen**: Charts showing completion rates, category distribution, and most-used items
8. **Settings Screen**: Theme toggle, data management, and app information
9. **Backup & Restore**: JSON export/import for data portability
10. **Schedule Screen**: Assign future shopping dates to lists
11. **Splash Screen**: Animated app launch experience

### 🎨 UI/UX Features
- **Responsive Design**: Works on all screen sizes
- **Smooth Animations**: Staggered list animations and empty state animations
- **Custom App Icon**: Professional grocery-themed icon
- **Empty States**: Engaging animations for empty lists and search results
- **Swipe Actions**: Intuitive gestures for item management

### 📊 Data Management
- **Categories**: Pre-defined categories (Fruits, Vegetables, Dairy, etc.) with custom category support
- **Item Properties**: Name, quantity, category, notes, completion status, importance
- **List Properties**: Title, description, scheduled date, favorite status, completion tracking
- **Statistics**: Track usage patterns and shopping habits

### 🔧 Technical Features
- **State Management**: Riverpod for reactive state management
- **Local Storage**: Hive database for fast, offline data persistence
- **Type Safety**: Full Dart type safety with code generation
- **Performance**: Optimized list rendering and smooth animations

## Installation

### Prerequisites
- Flutter SDK (3.0 or higher)
- Dart SDK (2.17 or higher)
- Android Studio / VS Code with Flutter extensions

### Setup
1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd grocery_list_app
   ```

2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Generate code for Hive adapters:
   ```bash
   flutter packages pub run build_runner build
   ```

4. Run the app:
   ```bash
   flutter run
   ```

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/                   # Data models
│   ├── category.dart
│   ├── grocery_item.dart
│   └── grocery_list.dart
├── providers/                # State management
│   ├── theme_provider.dart
│   ├── grocery_lists_provider.dart
│   ├── grocery_items_provider.dart
│   └── categories_provider.dart
├── screens/                  # UI screens
│   ├── home_screen.dart
│   ├── list_detail_screen.dart
│   ├── add_item_screen.dart
│   ├── search_filter_screen.dart
│   ├── statistics_screen.dart
│   ├── settings_screen.dart
│   ├── backup_restore_screen.dart
│   ├── schedule_screen.dart
│   ├── category_management_screen.dart
│   └── splash_screen.dart
├── widgets/                  # Reusable widgets
│   ├── grocery_list_card.dart
│   ├── grocery_item_tile.dart
│   └── empty_state_animation.dart
└── services/                 # Business logic
    └── database_service.dart
```

## Dependencies

### Core Dependencies
- `flutter_riverpod`: State management
- `hive_flutter`: Local database
- `hive_generator`: Code generation for Hive
- `build_runner`: Build system

### UI Dependencies
- `fl_chart`: Charts and graphs
- `flutter_staggered_animations`: List animations
- `file_picker`: File selection for backup/restore
- `path_provider`: File system access
- `intl`: Date formatting

### Development Dependencies
- `flutter_lints`: Code analysis
- `json_annotation`: JSON serialization

## Usage

### Creating Lists
1. Tap the "+" button on the home screen
2. Enter list title and optional description
3. Set a scheduled date if needed
4. Start adding items to your list

### Managing Items
1. Tap on a list to view items
2. Use the "+" button to add new items
3. Tap checkboxes to mark items as completed
4. Swipe left on items to delete
5. Tap the star icon to mark items as important

### Categories
1. Go to Settings > Manage Categories
2. Add custom categories with icons and colors
3. Edit or delete existing categories
4. Reset to default categories if needed

### Search & Filter
1. Use the search screen to find items across all lists
2. Filter by completion status or category
3. Search both items and lists simultaneously

### Statistics
1. View completion rates and trends
2. See category distribution charts
3. Track most frequently used items
4. Monitor recent activity

### Backup & Restore
1. Export data as JSON file for backup
2. Import previously exported data
3. All data remains local to your device

### Scheduling
1. Assign dates to shopping lists
2. View today's, tomorrow's, and upcoming lists
3. Track overdue lists
4. Reschedule lists as needed

## Customization

### Themes
- Switch between light, dark, and system themes
- Material 3 color schemes with green accent
- Consistent design language throughout

### Categories
- Create custom categories with emojis
- Choose from 12 predefined colors
- Organize items by your shopping habits

### Data Management
- Export/import for device migration
- Reset all data when needed
- Privacy-focused local storage

## Performance

- **Fast Startup**: Optimized splash screen and initialization
- **Smooth Scrolling**: Efficient list rendering with animations
- **Responsive UI**: Adaptive layouts for different screen sizes
- **Memory Efficient**: Proper resource management and disposal

## Privacy

- **Local Storage**: All data stays on your device
- **No Internet Required**: Fully offline functionality
- **No Tracking**: No analytics or data collection
- **User Control**: Complete control over your data

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues, feature requests, or questions:
1. Check the existing issues
2. Create a new issue with detailed description
3. Include device information and steps to reproduce

## Roadmap

### Future Enhancements
- [ ] Barcode scanning for items
- [ ] Recipe integration
- [ ] Shopping list sharing
- [ ] Price tracking
- [ ] Store location mapping
- [ ] Voice input for items
- [ ] Widget support
- [ ] Wear OS companion app

## Acknowledgments

- Flutter team for the amazing framework
- Material Design team for design guidelines
- Hive team for the excellent local database
- Riverpod team for state management solution
- FL Chart team for beautiful charts

---

**Built with ❤️ using Flutter**

