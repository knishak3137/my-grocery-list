import 'package:flutter/material.dart';

class EmptyStateAnimation extends StatefulWidget {
  final String type;
  final double size;

  const EmptyStateAnimation({
    super.key,
    required this.type,
    this.size = 120,
  });

  @override
  State<EmptyStateAnimation> createState() => _EmptyStateAnimationState();
}

class _EmptyStateAnimationState extends State<EmptyStateAnimation>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _rotationAnimation = Tween<double>(
      begin: 0,
      end: 0.1,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: 0.6,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Transform.rotate(
            angle: _rotationAnimation.value,
            child: Opacity(
              opacity: _opacityAnimation.value,
              child: Container(
                width: widget.size,
                height: widget.size,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceVariant,
                  borderRadius: BorderRadius.circular(widget.size / 2),
                ),
                child: _buildAnimationContent(),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildAnimationContent() {
    IconData icon;
    Color color;

    switch (widget.type) {
      case 'empty_list':
        icon = Icons.shopping_basket_outlined;
        color = Colors.orange;
        break;
      case 'empty_items':
        icon = Icons.inventory_2_outlined;
        color = Colors.blue;
        break;
      case 'empty_search':
        icon = Icons.search_off;
        color = Colors.grey;
        break;
      case 'empty_categories':
        icon = Icons.category_outlined;
        color = Colors.purple;
        break;
      case 'empty_schedule':
        icon = Icons.schedule;
        color = Colors.green;
        break;
      case 'no_data':
        icon = Icons.inbox_outlined;
        color = Colors.grey;
        break;
      default:
        icon = Icons.help_outline;
        color = Colors.grey;
    }

    return Stack(
      alignment: Alignment.center,
      children: [
        // Background circles for depth
        Container(
          width: widget.size * 0.8,
          height: widget.size * 0.8,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
        ),
        Container(
          width: widget.size * 0.6,
          height: widget.size * 0.6,
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            shape: BoxShape.circle,
          ),
        ),
        // Main icon
        Icon(
          icon,
          size: widget.size * 0.4,
          color: color,
        ),
        // Floating particles effect
        ...List.generate(3, (index) {
          return AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              final offset = Offset(
                (index - 1) * 20 * _scaleAnimation.value,
                -10 * _scaleAnimation.value,
              );
              return Transform.translate(
                offset: offset,
                child: Container(
                  width: 4,
                  height: 4,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.5),
                    shape: BoxShape.circle,
                  ),
                ),
              );
            },
          );
        }),
      ],
    );
  }
}

class PulsingEmptyState extends StatefulWidget {
  final IconData icon;
  final Color color;
  final double size;

  const PulsingEmptyState({
    super.key,
    required this.icon,
    required this.color,
    this.size = 120,
  });

  @override
  State<PulsingEmptyState> createState() => _PulsingEmptyStateState();
}

class _PulsingEmptyStateState extends State<PulsingEmptyState>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.3,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Container(
            width: widget.size,
            height: widget.size,
            decoration: BoxDecoration(
              color: widget.color.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              widget.icon,
              size: widget.size * 0.5,
              color: widget.color,
            ),
          ),
        );
      },
    );
  }
}

class FloatingEmptyState extends StatefulWidget {
  final IconData icon;
  final Color color;
  final double size;

  const FloatingEmptyState({
    super.key,
    required this.icon,
    required this.color,
    this.size = 120,
  });

  @override
  State<FloatingEmptyState> createState() => _FloatingEmptyStateState();
}

class _FloatingEmptyStateState extends State<FloatingEmptyState>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _floatAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );

    _floatAnimation = Tween<Offset>(
      begin: const Offset(0, -0.1),
      end: const Offset(0, 0.1),
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _floatAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: _floatAnimation.value * 20,
          child: Container(
            width: widget.size,
            height: widget.size,
            decoration: BoxDecoration(
              color: widget.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(widget.size / 4),
            ),
            child: Icon(
              widget.icon,
              size: widget.size * 0.5,
              color: widget.color,
            ),
          ),
        );
      },
    );
  }
}

