import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../models/grocery_list.dart';
import '../providers/grocery_items_provider.dart';

class GroceryListCard extends ConsumerWidget {
  final GroceryList groceryList;
  final VoidCallback onTap;
  final VoidCallback onFavoriteToggle;
  final VoidCallback onDelete;
  final VoidCallback onEdit;

  const GroceryListCard({
    super.key,
    required this.groceryList,
    required this.onTap,
    required this.onFavoriteToggle,
    required this.onDelete,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allItems = ref.watch(groceryItemsProvider);
    final listItems = allItems.where((item) => groceryList.itemIds.contains(item.id)).toList();
    final completedCount = listItems.where((item) => item.isCompleted).length;
    final totalCount = listItems.length;
    final completionPercentage = totalCount > 0 ? completedCount / totalCount : 0.0;

    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                groceryList.displayTitle,
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  decoration: groceryList.isCompleted 
                                      ? TextDecoration.lineThrough 
                                      : null,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (groceryList.isCompleted)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.green,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Text(
                                  'COMPLETED',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        if (groceryList.description.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            groceryList.description,
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      switch (value) {
                        case 'edit':
                          onEdit();
                          break;
                        case 'favorite':
                          onFavoriteToggle();
                          break;
                        case 'delete':
                          onDelete();
                          break;
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Row(
                          children: [
                            Icon(Icons.edit),
                            SizedBox(width: 8),
                            Text('Edit'),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        value: 'favorite',
                        child: Row(
                          children: [
                            Icon(groceryList.isFavorite 
                                ? Icons.favorite 
                                : Icons.favorite_border),
                            const SizedBox(width: 8),
                            Text(groceryList.isFavorite 
                                ? 'Remove from Favorites' 
                                : 'Add to Favorites'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    Icons.shopping_cart_outlined,
                    size: 16,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '$totalCount ${totalCount == 1 ? 'item' : 'items'}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  if (totalCount > 0) ...[
                    const SizedBox(width: 16),
                    Icon(
                      Icons.check_circle_outline,
                      size: 16,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '$completedCount completed',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  const Spacer(),
                  if (groceryList.isFavorite)
                    Icon(
                      Icons.favorite,
                      size: 16,
                      color: Colors.red,
                    ),
                ],
              ),
              if (groceryList.scheduledDate != null) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(
                      Icons.schedule,
                      size: 16,
                      color: groceryList.isOverdue 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _formatScheduleDate(groceryList.scheduledDate!),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: groceryList.isOverdue 
                            ? Colors.red 
                            : Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
              if (totalCount > 0) ...[
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: completionPercentage,
                  backgroundColor: Theme.of(context).colorScheme.surfaceVariant,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    completionPercentage == 1.0 
                        ? Colors.green 
                        : Theme.of(context).colorScheme.primary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${(completionPercentage * 100).round()}% complete',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _formatScheduleDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));
    final scheduleDate = DateTime(date.year, date.month, date.day);

    if (scheduleDate == today) {
      return 'Today at ${DateFormat.jm().format(date)}';
    } else if (scheduleDate == tomorrow) {
      return 'Tomorrow at ${DateFormat.jm().format(date)}';
    } else if (scheduleDate.isBefore(today)) {
      final difference = today.difference(scheduleDate).inDays;
      return '$difference ${difference == 1 ? 'day' : 'days'} ago';
    } else {
      final difference = scheduleDate.difference(today).inDays;
      if (difference <= 7) {
        return 'In $difference ${difference == 1 ? 'day' : 'days'}';
      } else {
        return DateFormat.yMMMd().format(date);
      }
    }
  }
}

