import 'package:flutter/material.dart';
import '../models/grocery_item.dart';
import '../models/category.dart';

class GroceryItemTile extends StatelessWidget {
  final GroceryItem item;
  final Category? category;
  final VoidCallback onToggleCompleted;
  final VoidCallback onToggleImportant;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const GroceryItemTile({
    super.key,
    required this.item,
    this.category,
    required this.onToggleCompleted,
    required this.onToggleImportant,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(item.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Icon(
          Icons.delete,
          color: Colors.white,
          size: 24,
        ),
      ),
      confirmDismiss: (direction) async {
        return await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Delete Item'),
            content: Text('Are you sure you want to delete "${item.name}"?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Delete'),
              ),
            ],
          ),
        ) ?? false;
      },
      onDismissed: (direction) => onDelete(),
      child: Card(
        margin: EdgeInsets.zero,
        child: ListTile(
          leading: Checkbox(
            value: item.isCompleted,
            onChanged: (value) => onToggleCompleted(),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  item.displayName,
                  style: TextStyle(
                    decoration: item.isCompleted 
                        ? TextDecoration.lineThrough 
                        : null,
                    color: item.isCompleted 
                        ? Theme.of(context).colorScheme.onSurfaceVariant
                        : null,
                    fontWeight: item.isImportant 
                        ? FontWeight.bold 
                        : FontWeight.normal,
                  ),
                ),
              ),
              if (item.isImportant)
                Container(
                  margin: const EdgeInsets.only(left: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'IMPORTANT',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (category != null) ...[
                    Text(
                      category!.icon,
                      style: const TextStyle(fontSize: 12),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      category!.name,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    'Qty: ${item.displayQuantity}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  if (item.price != null) ...[
                    const SizedBox(width: 8),
                    Text(
                      '\$${item.price!.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
              if (item.brand != null && item.brand!.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  'Brand: ${item.brand}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
              if (item.notes.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(
                  item.notes,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
          trailing: PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'edit':
                  onEdit();
                  break;
                case 'important':
                  onToggleImportant();
                  break;
                case 'delete':
                  onDelete();
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit),
                    SizedBox(width: 8),
                    Text('Edit'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'important',
                child: Row(
                  children: [
                    Icon(item.isImportant 
                        ? Icons.star 
                        : Icons.star_border),
                    const SizedBox(width: 8),
                    Text(item.isImportant 
                        ? 'Remove from Important' 
                        : 'Mark as Important'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Delete', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
          onTap: onToggleCompleted,
        ),
      ),
    );
  }
}

