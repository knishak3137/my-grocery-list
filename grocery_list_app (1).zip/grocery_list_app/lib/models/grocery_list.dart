import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';
import 'grocery_item.dart';

part 'grocery_list.g.dart';

@HiveType(typeId: 2)
@JsonSerializable()
class GroceryList {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String description;

  @HiveField(3)
  final List<String> itemIds;

  @HiveField(4)
  final DateTime createdAt;

  @HiveField(5)
  final DateTime updatedAt;

  @HiveField(6)
  final DateTime? scheduledDate;

  @HiveField(7)
  final bool isCompleted;

  @HiveField(8)
  final int color;

  @HiveField(9)
  final String? notes;

  @HiveField(10)
  final bool isFavorite;

  GroceryList({
    required this.id,
    required this.title,
    this.description = '',
    required this.itemIds,
    required this.createdAt,
    required this.updatedAt,
    this.scheduledDate,
    this.isCompleted = false,
    this.color = 0xFF4CAF50,
    this.notes,
    this.isFavorite = false,
  });

  GroceryList copyWith({
    String? id,
    String? title,
    String? description,
    List<String>? itemIds,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? scheduledDate,
    bool? isCompleted,
    int? color,
    String? notes,
    bool? isFavorite,
  }) {
    return GroceryList(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      itemIds: itemIds ?? List<String>.from(this.itemIds),
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      scheduledDate: scheduledDate ?? this.scheduledDate,
      isCompleted: isCompleted ?? this.isCompleted,
      color: color ?? this.color,
      notes: notes ?? this.notes,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  factory GroceryList.fromJson(Map<String, dynamic> json) => _$GroceryListFromJson(json);
  Map<String, dynamic> toJson() => _$GroceryListToJson(this);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GroceryList && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'GroceryList{id: $id, title: $title, itemCount: ${itemIds.length}, isCompleted: $isCompleted}';
  }

  // Helper methods
  String get displayTitle => title.trim().isEmpty ? 'Untitled List' : title;
  
  int get itemCount => itemIds.length;
  
  bool get hasScheduledDate => scheduledDate != null;
  
  bool get isOverdue {
    if (scheduledDate == null || isCompleted) return false;
    return DateTime.now().isAfter(scheduledDate!);
  }
  
  bool get isScheduledToday {
    if (scheduledDate == null) return false;
    final now = DateTime.now();
    final scheduled = scheduledDate!;
    return now.year == scheduled.year &&
           now.month == scheduled.month &&
           now.day == scheduled.day;
  }
  
  bool get isScheduledTomorrow {
    if (scheduledDate == null) return false;
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final scheduled = scheduledDate!;
    return tomorrow.year == scheduled.year &&
           tomorrow.month == scheduled.month &&
           tomorrow.day == scheduled.day;
  }

  String get scheduleStatus {
    if (scheduledDate == null) return 'No schedule';
    if (isCompleted) return 'Completed';
    if (isOverdue) return 'Overdue';
    if (isScheduledToday) return 'Today';
    if (isScheduledTomorrow) return 'Tomorrow';
    
    final now = DateTime.now();
    final difference = scheduledDate!.difference(now).inDays;
    if (difference > 0) {
      return 'In $difference days';
    } else if (difference == 0) {
      return 'Today';
    } else {
      return '${difference.abs()} days ago';
    }
  }

  // Create a new grocery list
  static GroceryList create({
    required String title,
    String description = '',
    DateTime? scheduledDate,
    int color = 0xFF4CAF50,
    String? notes,
  }) {
    final now = DateTime.now();
    return GroceryList(
      id: '${now.millisecondsSinceEpoch}_${title.hashCode}',
      title: title,
      description: description,
      itemIds: [],
      createdAt: now,
      updatedAt: now,
      scheduledDate: scheduledDate,
      color: color,
      notes: notes,
    );
  }

  // Add item to list
  GroceryList addItem(String itemId) {
    if (itemIds.contains(itemId)) return this;
    
    return copyWith(
      itemIds: [...itemIds, itemId],
      updatedAt: DateTime.now(),
    );
  }

  // Remove item from list
  GroceryList removeItem(String itemId) {
    return copyWith(
      itemIds: itemIds.where((id) => id != itemId).toList(),
      updatedAt: DateTime.now(),
    );
  }

  // Toggle favorite status
  GroceryList toggleFavorite() {
    return copyWith(
      isFavorite: !isFavorite,
      updatedAt: DateTime.now(),
    );
  }

  // Mark as completed
  GroceryList markCompleted() {
    return copyWith(
      isCompleted: true,
      updatedAt: DateTime.now(),
    );
  }

  // Mark as incomplete
  GroceryList markIncomplete() {
    return copyWith(
      isCompleted: false,
      updatedAt: DateTime.now(),
    );
  }

  // Update schedule
  GroceryList updateSchedule(DateTime? newScheduledDate) {
    return copyWith(
      scheduledDate: newScheduledDate,
      updatedAt: DateTime.now(),
    );
  }

  // Calculate completion percentage based on items
  double getCompletionPercentage(List<GroceryItem> items) {
    if (itemIds.isEmpty) return 0.0;
    
    final listItems = items.where((item) => itemIds.contains(item.id)).toList();
    if (listItems.isEmpty) return 0.0;
    
    final completedCount = listItems.where((item) => item.isCompleted).length;
    return completedCount / listItems.length;
  }

  // Get completed item count
  int getCompletedItemCount(List<GroceryItem> items) {
    final listItems = items.where((item) => itemIds.contains(item.id)).toList();
    return listItems.where((item) => item.isCompleted).length;
  }

  // Get pending item count
  int getPendingItemCount(List<GroceryItem> items) {
    final listItems = items.where((item) => itemIds.contains(item.id)).toList();
    return listItems.where((item) => !item.isCompleted).length;
  }

  // Check if list is auto-completed (all items completed)
  bool isAutoCompleted(List<GroceryItem> items) {
    if (itemIds.isEmpty) return false;
    final listItems = items.where((item) => itemIds.contains(item.id)).toList();
    return listItems.isNotEmpty && listItems.every((item) => item.isCompleted);
  }
}


  // JSON serialization
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'itemIds': itemIds,
      'isCompleted': isCompleted,
      'isFavorite': isFavorite,
      'scheduledDate': scheduledDate?.toIso8601String(),
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory GroceryList.fromJson(Map<String, dynamic> json) {
    return GroceryList(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      itemIds: List<String>.from(json['itemIds'] ?? []),
      isCompleted: json['isCompleted'] ?? false,
      isFavorite: json['isFavorite'] ?? false,
      scheduledDate: json['scheduledDate'] != null 
          ? DateTime.parse(json['scheduledDate'])
          : null,
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
    );
  }

