import 'package:hive/hive.dart';
import 'package:json_annotation/json_annotation.dart';

part 'grocery_item.g.dart';

@HiveType(typeId: 1)
@JsonSerializable()
class GroceryItem {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String name;

  @HiveField(2)
  final String quantity;

  @HiveField(3)
  final String categoryId;

  @HiveField(4)
  final bool isCompleted;

  @HiveField(5)
  final bool isImportant;

  @HiveField(6)
  final String notes;

  @HiveField(7)
  final DateTime createdAt;

  @HiveField(8)
  final DateTime updatedAt;

  @HiveField(9)
  final DateTime? completedAt;

  @HiveField(10)
  final double? price;

  @HiveField(11)
  final String? brand;

  GroceryItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.categoryId,
    this.isCompleted = false,
    this.isImportant = false,
    this.notes = '',
    required this.createdAt,
    required this.updatedAt,
    this.completedAt,
    this.price,
    this.brand,
  });

  GroceryItem copyWith({
    String? id,
    String? name,
    String? quantity,
    String? categoryId,
    bool? isCompleted,
    bool? isImportant,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? completedAt,
    double? price,
    String? brand,
  }) {
    return GroceryItem(
      id: id ?? this.id,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      categoryId: categoryId ?? this.categoryId,
      isCompleted: isCompleted ?? this.isCompleted,
      isImportant: isImportant ?? this.isImportant,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      completedAt: completedAt ?? this.completedAt,
      price: price ?? this.price,
      brand: brand ?? this.brand,
    );
  }

  factory GroceryItem.fromJson(Map<String, dynamic> json) => _$GroceryItemFromJson(json);
  Map<String, dynamic> toJson() => _$GroceryItemToJson(this);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GroceryItem && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'GroceryItem{id: $id, name: $name, quantity: $quantity, categoryId: $categoryId, isCompleted: $isCompleted, isImportant: $isImportant}';
  }

  // Helper methods
  String get displayName => name.trim().isEmpty ? 'Unnamed Item' : name;
  
  String get displayQuantity => quantity.trim().isEmpty ? '1' : quantity;
  
  String get status {
    if (isCompleted) return 'Completed';
    if (isImportant) return 'Important';
    return 'Pending';
  }

  // Create a new item with current timestamp
  static GroceryItem create({
    required String name,
    required String quantity,
    required String categoryId,
    bool isImportant = false,
    String notes = '',
    double? price,
    String? brand,
  }) {
    final now = DateTime.now();
    return GroceryItem(
      id: '${now.millisecondsSinceEpoch}_${name.hashCode}',
      name: name,
      quantity: quantity,
      categoryId: categoryId,
      isImportant: isImportant,
      notes: notes,
      createdAt: now,
      updatedAt: now,
      price: price,
      brand: brand,
    );
  }

  // Toggle completion status
  GroceryItem toggleCompleted() {
    final now = DateTime.now();
    return copyWith(
      isCompleted: !isCompleted,
      updatedAt: now,
      completedAt: !isCompleted ? now : null,
    );
  }

  // Toggle important status
  GroceryItem toggleImportant() {
    return copyWith(
      isImportant: !isImportant,
      updatedAt: DateTime.now(),
    );
  }
}


  // JSON serialization
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'quantity': quantity,
      'unit': unit,
      'categoryId': categoryId,
      'notes': notes,
      'brand': brand,
      'price': price,
      'isCompleted': isCompleted,
      'isImportant': isImportant,
      'listId': listId,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory GroceryItem.fromJson(Map<String, dynamic> json) {
    return GroceryItem(
      id: json['id'],
      name: json['name'],
      quantity: json['quantity'],
      unit: json['unit'],
      categoryId: json['categoryId'],
      notes: json['notes'] ?? '',
      brand: json['brand'],
      price: json['price']?.toDouble(),
      isCompleted: json['isCompleted'] ?? false,
      isImportant: json['isImportant'] ?? false,
      listId: json['listId'],
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
    );
  }

