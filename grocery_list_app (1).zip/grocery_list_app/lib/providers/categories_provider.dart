import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/category.dart';
import '../services/database_service.dart';

// Categories Provider
final categoriesProvider = StateNotifierProvider<CategoriesNotifier, List<Category>>((ref) {
  return CategoriesNotifier();
});

class CategoriesNotifier extends StateNotifier<List<Category>> {
  CategoriesNotifier() : super([]) {
    loadCategories();
  }

  Future<void> loadCategories() async {
    final categories = DatabaseService.instance.getAllCategories();
    state = categories;
  }

  Future<void> addCategory(Category category) async {
    await DatabaseService.instance.saveCategory(category);
    state = [...state, category];
  }

  Future<void> updateCategory(Category updatedCategory) async {
    await DatabaseService.instance.saveCategory(updatedCategory);
    state = state.map((category) => 
        category.id == updatedCategory.id ? updatedCategory : category
    ).toList();
  }

  Future<void> deleteCategory(String categoryId) async {
    // Check if it's a default category
    final defaultIds = Category.defaultCategories.map((c) => c.id).toSet();
    if (defaultIds.contains(categoryId)) {
      return; // Don't allow deletion of default categories
    }
    
    await DatabaseService.instance.deleteCategory(categoryId);
    state = state.where((category) => category.id != categoryId).toList();
  }

  Category? getCategoryById(String categoryId) {
    try {
      return state.firstWhere((category) => category.id == categoryId);
    } catch (e) {
      return null;
    }
  }

  List<Category> searchCategories(String query) {
    if (query.trim().isEmpty) return state;
    
    final lowercaseQuery = query.toLowerCase();
    return state.where((category) =>
        category.name.toLowerCase().contains(lowercaseQuery)
    ).toList();
  }

  bool isDefaultCategory(String categoryId) {
    final defaultIds = Category.defaultCategories.map((c) => c.id).toSet();
    return defaultIds.contains(categoryId);
  }

  List<Category> getDefaultCategories() {
    final defaultIds = Category.defaultCategories.map((c) => c.id).toSet();
    return state.where((category) => defaultIds.contains(category.id)).toList();
  }

  List<Category> getCustomCategories() {
    final defaultIds = Category.defaultCategories.map((c) => c.id).toSet();
    return state.where((category) => !defaultIds.contains(category.id)).toList();
  }

  // Reset to default categories
  Future<void> resetToDefaults() async {
    // Clear all categories
    for (final category in state) {
      await DatabaseService.instance.deleteCategory(category.id);
    }
    
    // Add default categories
    for (final category in Category.defaultCategories) {
      await DatabaseService.instance.saveCategory(category);
    }
    
    await loadCategories();
  }
}

// Selected Category Provider
final selectedCategoryProvider = StateProvider<Category?>((ref) => null);

// Category Search Provider
final categorySearchQueryProvider = StateProvider<String>((ref) => '');

// Filtered Categories Provider
final filteredCategoriesProvider = Provider<List<Category>>((ref) {
  final categories = ref.watch(categoriesProvider);
  final searchQuery = ref.watch(categorySearchQueryProvider);
  
  if (searchQuery.trim().isEmpty) return categories;
  
  final lowercaseQuery = searchQuery.toLowerCase();
  return categories.where((category) =>
      category.name.toLowerCase().contains(lowercaseQuery)
  ).toList();
});


// Additional providers for search and filtering
final categorySearchQueryProvider = StateProvider<String>((ref) => '');

final filteredCategoriesProvider = Provider<List<Category>>((ref) {
  final categories = ref.watch(categoriesProvider);
  final searchQuery = ref.watch(categorySearchQueryProvider);

  if (searchQuery.isEmpty) {
    return categories;
  }

  return categories.where((category) {
    return category.name.toLowerCase().contains(searchQuery.toLowerCase());
  }).toList();
});

