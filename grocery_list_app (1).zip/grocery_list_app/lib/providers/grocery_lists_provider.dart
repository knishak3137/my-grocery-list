import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/grocery_list.dart';
import '../models/grocery_item.dart';
import '../services/database_service.dart';

// Grocery Lists Provider
final groceryListsProvider = StateNotifierProvider<GroceryListsNotifier, List<GroceryList>>((ref) {
  return GroceryListsNotifier();
});

class GroceryListsNotifier extends StateNotifier<List<GroceryList>> {
  GroceryListsNotifier() : super([]) {
    loadGroceryLists();
  }

  Future<void> loadGroceryLists() async {
    final lists = DatabaseService.instance.getAllGroceryLists();
    state = lists;
  }

  Future<void> addGroceryList(GroceryList list) async {
    await DatabaseService.instance.saveGroceryList(list);
    state = [...state, list];
  }

  Future<void> updateGroceryList(GroceryList updatedList) async {
    await DatabaseService.instance.saveGroceryList(updatedList);
    state = state.map((list) => list.id == updatedList.id ? updatedList : list).toList();
  }

  Future<void> deleteGroceryList(String listId) async {
    await DatabaseService.instance.deleteGroceryList(listId);
    state = state.where((list) => list.id != listId).toList();
  }

  Future<void> toggleListFavorite(String listId) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.toggleFavorite();
    await updateGroceryList(updatedList);
  }

  Future<void> markListCompleted(String listId) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.markCompleted();
    await updateGroceryList(updatedList);
  }

  Future<void> markListIncomplete(String listId) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.markIncomplete();
    await updateGroceryList(updatedList);
  }

  Future<void> updateListSchedule(String listId, DateTime? scheduledDate) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.updateSchedule(scheduledDate);
    await updateGroceryList(updatedList);
  }

  Future<void> addItemToList(String listId, String itemId) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.addItem(itemId);
    await updateGroceryList(updatedList);
  }

  Future<void> removeItemFromList(String listId, String itemId) async {
    final list = state.firstWhere((list) => list.id == listId);
    final updatedList = list.removeItem(itemId);
    await updateGroceryList(updatedList);
  }

  List<GroceryList> searchLists(String query) {
    if (query.trim().isEmpty) return state;
    
    final lowercaseQuery = query.toLowerCase();
    return state.where((list) =>
        list.title.toLowerCase().contains(lowercaseQuery) ||
        list.description.toLowerCase().contains(lowercaseQuery) ||
        (list.notes?.toLowerCase().contains(lowercaseQuery) ?? false)
    ).toList();
  }

  List<GroceryList> getFavoriteLists() {
    return state.where((list) => list.isFavorite).toList();
  }

  List<GroceryList> getScheduledLists() {
    return state.where((list) => list.scheduledDate != null).toList()
      ..sort((a, b) => a.scheduledDate!.compareTo(b.scheduledDate!));
  }

  List<GroceryList> getCompletedLists() {
    return state.where((list) => list.isCompleted).toList();
  }

  List<GroceryList> getPendingLists() {
    return state.where((list) => !list.isCompleted).toList();
  }

  GroceryList? getListById(String listId) {
    try {
      return state.firstWhere((list) => list.id == listId);
    } catch (e) {
      return null;
    }
  }

  // Auto-complete lists when all items are completed
  Future<void> checkAutoCompletion(String listId, List<GroceryItem> allItems) async {
    final list = getListById(listId);
    if (list != null && !list.isCompleted && list.isAutoCompleted(allItems)) {
      await markListCompleted(listId);
    }
  }
}

// Selected List Provider (for navigation)
final selectedListProvider = StateProvider<GroceryList?>((ref) => null);

// Search Query Provider
final listSearchQueryProvider = StateProvider<String>((ref) => '');

// Filtered Lists Provider
final filteredGroceryListsProvider = Provider<List<GroceryList>>((ref) {
  final lists = ref.watch(groceryListsProvider);
  final searchQuery = ref.watch(listSearchQueryProvider);
  
  if (searchQuery.trim().isEmpty) return lists;
  
  final lowercaseQuery = searchQuery.toLowerCase();
  return lists.where((list) =>
      list.title.toLowerCase().contains(lowercaseQuery) ||
      list.description.toLowerCase().contains(lowercaseQuery) ||
      (list.notes?.toLowerCase().contains(lowercaseQuery) ?? false)
  ).toList();
});


// Additional providers for search and filtering
final listSearchQueryProvider = StateProvider<String>((ref) => '');

final selectedListProvider = StateProvider<GroceryList?>((ref) => null);

final filteredGroceryListsProvider = Provider<List<GroceryList>>((ref) {
  final lists = ref.watch(groceryListsProvider);
  final searchQuery = ref.watch(listSearchQueryProvider);

  if (searchQuery.isEmpty) {
    return lists;
  }

  return lists.where((list) {
    return list.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
           (list.description?.toLowerCase().contains(searchQuery.toLowerCase()) ?? false);
  }).toList();
});

// Extensions for GroceryList
extension GroceryListExtensions on GroceryList {
  bool get isScheduledToday {
    if (scheduledDate == null) return false;
    final now = DateTime.now();
    final scheduled = scheduledDate!;
    return scheduled.year == now.year &&
           scheduled.month == now.month &&
           scheduled.day == now.day;
  }

  bool get isScheduledTomorrow {
    if (scheduledDate == null) return false;
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final scheduled = scheduledDate!;
    return scheduled.year == tomorrow.year &&
           scheduled.month == tomorrow.month &&
           scheduled.day == tomorrow.day;
  }

  bool get isOverdue {
    if (scheduledDate == null) return false;
    return scheduledDate!.isBefore(DateTime.now()) && !isCompleted;
  }
}


  void updateListSchedule(String listId, DateTime? scheduledDate) {
    final lists = [...state];
    final index = lists.indexWhere((list) => list.id == listId);
    if (index != -1) {
      lists[index] = lists[index].copyWith(
        scheduledDate: scheduledDate,
        updatedAt: DateTime.now(),
      );
      state = lists;
      DatabaseService.instance.updateGroceryList(lists[index]);
    }
  }

