import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/grocery_item.dart';
import '../services/database_service.dart';
import 'grocery_lists_provider.dart';

// Grocery Items Provider
final groceryItemsProvider = StateNotifierProvider<GroceryItemsNotifier, List<GroceryItem>>((ref) {
  return GroceryItemsNotifier();
});

class GroceryItemsNotifier extends StateNotifier<List<GroceryItem>> {
  GroceryItemsNotifier() : super([]) {
    loadGroceryItems();
  }

  Future<void> loadGroceryItems() async {
    final items = DatabaseService.instance.getAllGroceryItems();
    state = items;
  }

  Future<void> addGroceryItem(GroceryItem item) async {
    await DatabaseService.instance.saveGroceryItem(item);
    state = [...state, item];
  }

  Future<void> updateGroceryItem(GroceryItem updatedItem) async {
    await DatabaseService.instance.saveGroceryItem(updatedItem);
    state = state.map((item) => item.id == updatedItem.id ? updatedItem : item).toList();
  }

  Future<void> deleteGroceryItem(String itemId) async {
    await DatabaseService.instance.deleteGroceryItem(itemId);
    state = state.where((item) => item.id != itemId).toList();
  }

  Future<void> toggleItemCompleted(String itemId) async {
    final item = state.firstWhere((item) => item.id == itemId);
    final updatedItem = item.toggleCompleted();
    await updateGroceryItem(updatedItem);
  }

  Future<void> toggleItemImportant(String itemId) async {
    final item = state.firstWhere((item) => item.id == itemId);
    final updatedItem = item.toggleImportant();
    await updateGroceryItem(updatedItem);
  }

  List<GroceryItem> getItemsByIds(List<String> itemIds) {
    return state.where((item) => itemIds.contains(item.id)).toList();
  }

  List<GroceryItem> searchItems(String query) {
    if (query.trim().isEmpty) return state;
    
    final lowercaseQuery = query.toLowerCase();
    return state.where((item) =>
        item.name.toLowerCase().contains(lowercaseQuery) ||
        item.notes.toLowerCase().contains(lowercaseQuery) ||
        (item.brand?.toLowerCase().contains(lowercaseQuery) ?? false)
    ).toList();
  }

  List<GroceryItem> filterItems({
    bool? isCompleted,
    bool? isImportant,
    String? categoryId,
  }) {
    return state.where((item) {
      if (isCompleted != null && item.isCompleted != isCompleted) return false;
      if (isImportant != null && item.isImportant != isImportant) return false;
      if (categoryId != null && item.categoryId != categoryId) return false;
      return true;
    }).toList();
  }

  List<GroceryItem> getCompletedItems() {
    return state.where((item) => item.isCompleted).toList();
  }

  List<GroceryItem> getPendingItems() {
    return state.where((item) => !item.isCompleted).toList();
  }

  List<GroceryItem> getImportantItems() {
    return state.where((item) => item.isImportant).toList();
  }

  List<GroceryItem> getItemsByCategory(String categoryId) {
    return state.where((item) => item.categoryId == categoryId).toList();
  }

  GroceryItem? getItemById(String itemId) {
    try {
      return state.firstWhere((item) => item.id == itemId);
    } catch (e) {
      return null;
    }
  }

  // Statistics
  Map<String, int> getItemStatistics() {
    return {
      'total': state.length,
      'completed': state.where((item) => item.isCompleted).length,
      'pending': state.where((item) => !item.isCompleted).length,
      'important': state.where((item) => item.isImportant).length,
    };
  }

  Map<String, int> getCategoryStatistics() {
    final stats = <String, int>{};
    for (final item in state) {
      stats[item.categoryId] = (stats[item.categoryId] ?? 0) + 1;
    }
    return stats;
  }

  List<String> getMostUsedItems({int limit = 10}) {
    final itemCounts = <String, int>{};
    
    for (final item in state) {
      itemCounts[item.name] = (itemCounts[item.name] ?? 0) + 1;
    }
    
    final sortedItems = itemCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sortedItems.take(limit).map((e) => e.key).toList();
  }
}

// Search and Filter Providers
final itemSearchQueryProvider = StateProvider<String>((ref) => '');

final itemFilterProvider = StateProvider<ItemFilter>((ref) => ItemFilter());

class ItemFilter {
  final bool? isCompleted;
  final bool? isImportant;
  final String? categoryId;
  final String status; // 'all', 'completed', 'pending', 'important'

  ItemFilter({
    this.isCompleted,
    this.isImportant,
    this.categoryId,
    this.status = 'all',
  });

  ItemFilter copyWith({
    bool? isCompleted,
    bool? isImportant,
    String? categoryId,
    String? status,
  }) {
    return ItemFilter(
      isCompleted: isCompleted ?? this.isCompleted,
      isImportant: isImportant ?? this.isImportant,
      categoryId: categoryId ?? this.categoryId,
      status: status ?? this.status,
    );
  }
}

// Filtered Items Provider
final filteredGroceryItemsProvider = Provider<List<GroceryItem>>((ref) {
  final items = ref.watch(groceryItemsProvider);
  final searchQuery = ref.watch(itemSearchQueryProvider);
  final filter = ref.watch(itemFilterProvider);
  
  List<GroceryItem> filteredItems = items;
  
  // Apply search filter
  if (searchQuery.trim().isNotEmpty) {
    final lowercaseQuery = searchQuery.toLowerCase();
    filteredItems = filteredItems.where((item) =>
        item.name.toLowerCase().contains(lowercaseQuery) ||
        item.notes.toLowerCase().contains(lowercaseQuery) ||
        (item.brand?.toLowerCase().contains(lowercaseQuery) ?? false)
    ).toList();
  }
  
  // Apply status filter
  switch (filter.status) {
    case 'completed':
      filteredItems = filteredItems.where((item) => item.isCompleted).toList();
      break;
    case 'pending':
      filteredItems = filteredItems.where((item) => !item.isCompleted).toList();
      break;
    case 'important':
      filteredItems = filteredItems.where((item) => item.isImportant).toList();
      break;
    case 'all':
    default:
      // No additional filtering
      break;
  }
  
  // Apply category filter
  if (filter.categoryId != null) {
    filteredItems = filteredItems.where((item) => item.categoryId == filter.categoryId).toList();
  }
  
  return filteredItems;
});

// List Items Provider (items for a specific list)
final listItemsProvider = Provider.family<List<GroceryItem>, String>((ref, listId) {
  final allItems = ref.watch(groceryItemsProvider);
  final lists = ref.watch(groceryListsProvider);
  
  final list = lists.where((list) => list.id == listId).firstOrNull;
  if (list == null) return [];
  
  return allItems.where((item) => list.itemIds.contains(item.id)).toList();
});



// Additional providers for search and filtering
final itemSearchQueryProvider = StateProvider<String>((ref) => '');

final itemFilterProvider = StateProvider<ItemFilter>((ref) => const ItemFilter());

final filteredGroceryItemsProvider = Provider<List<GroceryItem>>((ref) {
  final items = ref.watch(groceryItemsProvider);
  final searchQuery = ref.watch(itemSearchQueryProvider);
  final filter = ref.watch(itemFilterProvider);

  var filteredItems = items.where((item) {
    // Search filter
    if (searchQuery.isNotEmpty) {
      if (!item.name.toLowerCase().contains(searchQuery.toLowerCase())) {
        return false;
      }
    }

    // Status filter
    switch (filter.status) {
      case 'completed':
        if (!item.isCompleted) return false;
        break;
      case 'pending':
        if (item.isCompleted) return false;
        break;
      case 'important':
        if (!item.isImportant) return false;
        break;
    }

    // Category filter
    if (filter.categoryId != null) {
      if (item.categoryId != filter.categoryId) return false;
    }

    return true;
  }).toList();

  return filteredItems;
});

class ItemFilter {
  final String status;
  final String? categoryId;

  const ItemFilter({
    this.status = 'all',
    this.categoryId,
  });

  ItemFilter copyWith({
    String? status,
    String? categoryId,
  }) {
    return ItemFilter(
      status: status ?? this.status,
      categoryId: categoryId ?? this.categoryId,
    );
  }
}


  List<String> getMostUsedItems({int limit = 5}) {
    final itemCounts = <String, int>{};
    
    for (final item in state) {
      itemCounts[item.name] = (itemCounts[item.name] ?? 0) + 1;
    }

    final sortedItems = itemCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sortedItems.take(limit).map((e) => e.key).toList();
  }

