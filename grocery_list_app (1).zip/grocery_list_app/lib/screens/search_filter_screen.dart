import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

import '../models/grocery_item.dart';
import '../models/grocery_list.dart';
import '../providers/grocery_items_provider.dart';
import '../providers/grocery_lists_provider.dart';
import '../providers/categories_provider.dart';
import '../widgets/grocery_item_tile.dart';
import '../widgets/grocery_list_card.dart';
import 'list_detail_screen.dart';

class SearchFilterScreen extends ConsumerStatefulWidget {
  const SearchFilterScreen({super.key});

  @override
  ConsumerState<SearchFilterScreen> createState() => _SearchFilterScreenState();
}

class _SearchFilterScreenState extends ConsumerState<SearchFilterScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  
  String _selectedStatus = 'all'; // 'all', 'completed', 'pending', 'important'
  String? _selectedCategoryId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search & Filter'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Items', icon: Icon(Icons.shopping_basket)),
            Tab(text: 'Lists', icon: Icon(Icons.list)),
          ],
        ),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search items or lists...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _updateSearch();
                        },
                      )
                    : null,
                border: const OutlineInputBorder(),
              ),
              onChanged: (value) => _updateSearch(),
            ),
          ),

          // Filter Options
          Container(
            height: 60,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _buildStatusFilter(),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildCategoryFilter(),
                ),
              ],
            ),
          ),

          // Results
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildItemsTab(),
                _buildListsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusFilter() {
    return DropdownButtonFormField<String>(
      value: _selectedStatus,
      decoration: const InputDecoration(
        labelText: 'Status',
        border: OutlineInputBorder(),
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      items: const [
        DropdownMenuItem(value: 'all', child: Text('All Items')),
        DropdownMenuItem(value: 'completed', child: Text('Completed')),
        DropdownMenuItem(value: 'pending', child: Text('Pending')),
        DropdownMenuItem(value: 'important', child: Text('Important')),
      ],
      onChanged: (value) {
        setState(() {
          _selectedStatus = value!;
        });
        _updateFilters();
      },
    );
  }

  Widget _buildCategoryFilter() {
    final categories = ref.watch(categoriesProvider);
    
    return DropdownButtonFormField<String?>(
      value: _selectedCategoryId,
      decoration: const InputDecoration(
        labelText: 'Category',
        border: OutlineInputBorder(),
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      items: [
        const DropdownMenuItem<String?>(
          value: null,
          child: Text('All Categories'),
        ),
        ...categories.map((category) {
          return DropdownMenuItem<String?>(
            value: category.id,
            child: Row(
              children: [
                Text(category.icon, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Expanded(child: Text(category.name)),
              ],
            ),
          );
        }),
      ],
      onChanged: (value) {
        setState(() {
          _selectedCategoryId = value;
        });
        _updateFilters();
      },
    );
  }

  Widget _buildItemsTab() {
    final filteredItems = ref.watch(filteredGroceryItemsProvider);
    
    if (filteredItems.isEmpty) {
      return _buildEmptyState('No items found', 'Try adjusting your search or filters');
    }

    return AnimationLimiter(
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredItems.length,
        itemBuilder: (context, index) {
          final item = filteredItems[index];
          final categories = ref.watch(categoriesProvider);
          final category = categories.where((cat) => cat.id == item.categoryId).firstOrNull;

          return AnimationConfiguration.staggeredList(
            position: index,
            duration: const Duration(milliseconds: 375),
            child: SlideAnimation(
              verticalOffset: 50.0,
              child: FadeInAnimation(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: GroceryItemTile(
                    item: item,
                    category: category,
                    onToggleCompleted: () => _toggleItemCompleted(item.id),
                    onToggleImportant: () => _toggleItemImportant(item.id),
                    onEdit: () => _editItem(item),
                    onDelete: () => _deleteItem(item),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildListsTab() {
    final filteredLists = ref.watch(filteredGroceryListsProvider);
    
    if (filteredLists.isEmpty) {
      return _buildEmptyState('No lists found', 'Try adjusting your search');
    }

    return AnimationLimiter(
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredLists.length,
        itemBuilder: (context, index) {
          final list = filteredLists[index];

          return AnimationConfiguration.staggeredList(
            position: index,
            duration: const Duration(milliseconds: 375),
            child: SlideAnimation(
              verticalOffset: 50.0,
              child: FadeInAnimation(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GroceryListCard(
                    groceryList: list,
                    onTap: () => _navigateToListDetail(list),
                    onFavoriteToggle: () => _toggleListFavorite(list.id),
                    onDelete: () => _deleteList(list),
                    onEdit: () => _editList(list),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(String title, String subtitle) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(60),
              ),
              child: const Icon(
                Icons.search_off,
                size: 60,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _updateSearch() {
    ref.read(itemSearchQueryProvider.notifier).state = _searchController.text;
    ref.read(listSearchQueryProvider.notifier).state = _searchController.text;
  }

  void _updateFilters() {
    final filter = ref.read(itemFilterProvider.notifier);
    filter.state = filter.state.copyWith(
      status: _selectedStatus,
      categoryId: _selectedCategoryId,
    );
  }

  void _toggleItemCompleted(String itemId) {
    ref.read(groceryItemsProvider.notifier).toggleItemCompleted(itemId);
  }

  void _toggleItemImportant(String itemId) {
    ref.read(groceryItemsProvider.notifier).toggleItemImportant(itemId);
  }

  void _editItem(GroceryItem item) {
    // Navigate to edit item screen
    // Implementation depends on your navigation setup
  }

  void _deleteItem(GroceryItem item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Item'),
        content: Text('Are you sure you want to delete "${item.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              ref.read(groceryItemsProvider.notifier).deleteGroceryItem(item.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${item.name} deleted')),
              );
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _navigateToListDetail(GroceryList list) {
    ref.read(selectedListProvider.notifier).state = list;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ListDetailScreen(listId: list.id),
      ),
    );
  }

  void _toggleListFavorite(String listId) {
    ref.read(groceryListsProvider.notifier).toggleListFavorite(listId);
  }

  void _deleteList(GroceryList list) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete List'),
        content: Text('Are you sure you want to delete "${list.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              ref.read(groceryListsProvider.notifier).deleteGroceryList(list.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${list.title} deleted')),
              );
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _editList(GroceryList list) {
    // Navigate to edit list screen
    // Implementation depends on your navigation setup
  }
}

