import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

import '../models/grocery_list.dart';
import '../providers/grocery_lists_provider.dart';
import '../providers/grocery_items_provider.dart';
import '../widgets/grocery_list_card.dart';
import 'add_list_screen.dart';
import 'list_detail_screen.dart';
import 'search_filter_screen.dart';
import 'settings_screen.dart';
import 'statistics_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final groceryLists = ref.watch(groceryListsProvider);
    final groceryItems = ref.watch(groceryItemsProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Grocery Lists',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SearchFilterScreen(),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const StatisticsScreen(),
                ),
              );
            },
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'settings':
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SettingsScreen(),
                    ),
                  );
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'settings',
                child: Row(
                  children: [
                    Icon(Icons.settings),
                    SizedBox(width: 8),
                    Text('Settings'),
                  ],
                ),
              ),
            ],
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'All', icon: Icon(Icons.list)),
            Tab(text: 'Favorites', icon: Icon(Icons.favorite)),
            Tab(text: 'Scheduled', icon: Icon(Icons.schedule)),
            Tab(text: 'Completed', icon: Icon(Icons.check_circle)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildListView(groceryLists, groceryItems, 'all'),
          _buildListView(
            groceryLists.where((list) => list.isFavorite).toList(),
            groceryItems,
            'favorites',
          ),
          _buildListView(
            groceryLists.where((list) => list.scheduledDate != null).toList(),
            groceryItems,
            'scheduled',
          ),
          _buildListView(
            groceryLists.where((list) => list.isCompleted).toList(),
            groceryItems,
            'completed',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddListScreen(),
            ),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('New List'),
      ),
    );
  }

  Widget _buildListView(List<GroceryList> lists, List<dynamic> items, String type) {
    if (lists.isEmpty) {
      return _buildEmptyState(type);
    }

    return CustomScrollView(
      controller: _scrollController,
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                return AnimationConfiguration.staggeredList(
                  position: index,
                  duration: const Duration(milliseconds: 375),
                  child: SlideAnimation(
                    verticalOffset: 50.0,
                    child: FadeInAnimation(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: GroceryListCard(
                          groceryList: lists[index],
                          onTap: () => _navigateToListDetail(lists[index]),
                          onFavoriteToggle: () => _toggleFavorite(lists[index].id),
                          onDelete: () => _deleteList(lists[index]),
                          onEdit: () => _editList(lists[index]),
                        ),
                      ),
                    ),
                  ),
                );
              },
              childCount: lists.length,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState(String type) {
    String title;
    String subtitle;
    String animationAsset;

    switch (type) {
      case 'favorites':
        title = 'No Favorite Lists';
        subtitle = 'Mark lists as favorites to see them here';
        animationAsset = 'assets/animations/empty_favorites.json';
        break;
      case 'scheduled':
        title = 'No Scheduled Lists';
        subtitle = 'Schedule your shopping trips to see them here';
        animationAsset = 'assets/animations/empty_schedule.json';
        break;
      case 'completed':
        title = 'No Completed Lists';
        subtitle = 'Completed lists will appear here';
        animationAsset = 'assets/animations/empty_completed.json';
        break;
      default:
        title = 'No Grocery Lists';
        subtitle = 'Create your first grocery list to get started';
        animationAsset = 'assets/animations/empty_list.json';
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(100),
              ),
              child: const Icon(
                Icons.shopping_cart_outlined,
                size: 80,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            if (type == 'all') ...[
              const SizedBox(height: 32),
              FilledButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AddListScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.add),
                label: const Text('Create Your First List'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _navigateToListDetail(GroceryList list) {
    ref.read(selectedListProvider.notifier).state = list;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ListDetailScreen(listId: list.id),
      ),
    );
  }

  void _toggleFavorite(String listId) {
    ref.read(groceryListsProvider.notifier).toggleListFavorite(listId);
  }

  void _deleteList(GroceryList list) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete List'),
        content: Text('Are you sure you want to delete "${list.title}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              ref.read(groceryListsProvider.notifier).deleteGroceryList(list.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${list.title} deleted'),
                  action: SnackBarAction(
                    label: 'Undo',
                    onPressed: () {
                      // TODO: Implement undo functionality
                    },
                  ),
                ),
              );
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _editList(GroceryList list) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddListScreen(editingList: list),
      ),
    );
  }
}

