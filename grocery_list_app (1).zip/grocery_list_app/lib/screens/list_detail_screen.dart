import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

import '../models/grocery_item.dart';
import '../models/grocery_list.dart';
import '../providers/grocery_lists_provider.dart';
import '../providers/grocery_items_provider.dart';
import '../providers/categories_provider.dart';
import '../widgets/grocery_item_tile.dart';
import 'add_item_screen.dart';

class ListDetailScreen extends ConsumerStatefulWidget {
  final String listId;

  const ListDetailScreen({super.key, required this.listId});

  @override
  ConsumerState<ListDetailScreen> createState() => _ListDetailScreenState();
}

class _ListDetailScreenState extends ConsumerState<ListDetailScreen> {
  String _sortBy = 'created'; // 'created', 'name', 'category', 'status'
  bool _showCompleted = true;

  @override
  Widget build(BuildContext context) {
    final groceryList = ref.watch(groceryListsProvider)
        .where((list) => list.id == widget.listId)
        .firstOrNull;
    
    if (groceryList == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('List Not Found')),
        body: const Center(
          child: Text('This list no longer exists.'),
        ),
      );
    }

    final allItems = ref.watch(groceryItemsProvider);
    final categories = ref.watch(categoriesProvider);
    final listItems = allItems
        .where((item) => groceryList.itemIds.contains(item.id))
        .toList();

    final filteredItems = _showCompleted 
        ? listItems 
        : listItems.where((item) => !item.isCompleted).toList();

    final sortedItems = _sortItems(filteredItems);
    final completedCount = listItems.where((item) => item.isCompleted).length;
    final totalCount = listItems.length;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              groceryList.displayTitle,
              style: const TextStyle(fontSize: 18),
            ),
            if (totalCount > 0)
              Text(
                '$completedCount of $totalCount completed',
                style: const TextStyle(fontSize: 12),
              ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'sort_created':
                case 'sort_name':
                case 'sort_category':
                case 'sort_status':
                  setState(() {
                    _sortBy = value.substring(5);
                  });
                  break;
                case 'toggle_completed':
                  setState(() {
                    _showCompleted = !_showCompleted;
                  });
                  break;
                case 'mark_all_completed':
                  _markAllCompleted();
                  break;
                case 'clear_completed':
                  _clearCompleted();
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'sort_created',
                child: Row(
                  children: [
                    Icon(Icons.access_time),
                    SizedBox(width: 8),
                    Text('Sort by Date Created'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'sort_name',
                child: Row(
                  children: [
                    Icon(Icons.sort_by_alpha),
                    SizedBox(width: 8),
                    Text('Sort by Name'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'sort_category',
                child: Row(
                  children: [
                    Icon(Icons.category),
                    SizedBox(width: 8),
                    Text('Sort by Category'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'sort_status',
                child: Row(
                  children: [
                    Icon(Icons.check_circle),
                    SizedBox(width: 8),
                    Text('Sort by Status'),
                  ],
                ),
              ),
              const PopupMenuDivider(),
              PopupMenuItem(
                value: 'toggle_completed',
                child: Row(
                  children: [
                    Icon(_showCompleted ? Icons.visibility_off : Icons.visibility),
                    const SizedBox(width: 8),
                    Text(_showCompleted ? 'Hide Completed' : 'Show Completed'),
                  ],
                ),
              ),
              if (listItems.any((item) => !item.isCompleted))
                const PopupMenuItem(
                  value: 'mark_all_completed',
                  child: Row(
                    children: [
                      Icon(Icons.done_all),
                      SizedBox(width: 8),
                      Text('Mark All Completed'),
                    ],
                  ),
                ),
              if (listItems.any((item) => item.isCompleted))
                const PopupMenuItem(
                  value: 'clear_completed',
                  child: Row(
                    children: [
                      Icon(Icons.clear_all, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Clear Completed', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Progress indicator
          if (totalCount > 0)
            Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  LinearProgressIndicator(
                    value: totalCount > 0 ? completedCount / totalCount : 0,
                    backgroundColor: Theme.of(context).colorScheme.surfaceVariant,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      completedCount == totalCount 
                          ? Colors.green 
                          : Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${(completedCount / totalCount * 100).round()}% complete',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      Text(
                        '$completedCount / $totalCount items',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ],
              ),
            ),

          // Items list
          Expanded(
            child: sortedItems.isEmpty
                ? _buildEmptyState()
                : AnimationLimiter(
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: sortedItems.length,
                      itemBuilder: (context, index) {
                        final item = sortedItems[index];
                        final category = categories
                            .where((cat) => cat.id == item.categoryId)
                            .firstOrNull;

                        return AnimationConfiguration.staggeredList(
                          position: index,
                          duration: const Duration(milliseconds: 375),
                          child: SlideAnimation(
                            verticalOffset: 50.0,
                            child: FadeInAnimation(
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: GroceryItemTile(
                                  item: item,
                                  category: category,
                                  onToggleCompleted: () => _toggleItemCompleted(item.id),
                                  onToggleImportant: () => _toggleItemImportant(item.id),
                                  onEdit: () => _editItem(item),
                                  onDelete: () => _deleteItem(item),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addItem(),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(60),
              ),
              child: const Icon(
                Icons.shopping_basket_outlined,
                size: 60,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              _showCompleted ? 'No Items Yet' : 'No Pending Items',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _showCompleted 
                  ? 'Add items to your grocery list to get started'
                  : 'All items are completed! Great job!',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _addItem,
              icon: const Icon(Icons.add),
              label: const Text('Add Item'),
            ),
          ],
        ),
      ),
    );
  }

  List<GroceryItem> _sortItems(List<GroceryItem> items) {
    switch (_sortBy) {
      case 'name':
        items.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case 'category':
        final categories = ref.read(categoriesProvider);
        items.sort((a, b) {
          final catA = categories.where((cat) => cat.id == a.categoryId).firstOrNull;
          final catB = categories.where((cat) => cat.id == b.categoryId).firstOrNull;
          return (catA?.name ?? '').compareTo(catB?.name ?? '');
        });
        break;
      case 'status':
        items.sort((a, b) {
          if (a.isCompleted != b.isCompleted) {
            return a.isCompleted ? 1 : -1;
          }
          if (a.isImportant != b.isImportant) {
            return b.isImportant ? 1 : -1;
          }
          return 0;
        });
        break;
      case 'created':
      default:
        items.sort((a, b) => a.createdAt.compareTo(b.createdAt));
        break;
    }
    return items;
  }

  void _toggleItemCompleted(String itemId) {
    ref.read(groceryItemsProvider.notifier).toggleItemCompleted(itemId);
    
    // Check if list should be auto-completed
    final groceryList = ref.read(groceryListsProvider)
        .where((list) => list.id == widget.listId)
        .firstOrNull;
    if (groceryList != null) {
      ref.read(groceryListsProvider.notifier)
          .checkAutoCompletion(widget.listId, ref.read(groceryItemsProvider));
    }
  }

  void _toggleItemImportant(String itemId) {
    ref.read(groceryItemsProvider.notifier).toggleItemImportant(itemId);
  }

  void _addItem() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddItemScreen(listId: widget.listId),
      ),
    );
  }

  void _editItem(GroceryItem item) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddItemScreen(
          listId: widget.listId,
          editingItem: item,
        ),
      ),
    );
  }

  void _deleteItem(GroceryItem item) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Item'),
        content: Text('Are you sure you want to delete "${item.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              ref.read(groceryItemsProvider.notifier).deleteGroceryItem(item.id);
              ref.read(groceryListsProvider.notifier)
                  .removeItemFromList(widget.listId, item.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${item.name} deleted')),
              );
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _markAllCompleted() {
    final allItems = ref.read(groceryItemsProvider);
    final groceryList = ref.read(groceryListsProvider)
        .where((list) => list.id == widget.listId)
        .firstOrNull;
    
    if (groceryList != null) {
      final listItems = allItems
          .where((item) => groceryList.itemIds.contains(item.id))
          .where((item) => !item.isCompleted)
          .toList();
      
      for (final item in listItems) {
        ref.read(groceryItemsProvider.notifier).toggleItemCompleted(item.id);
      }
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${listItems.length} items marked as completed')),
      );
    }
  }

  void _clearCompleted() {
    final allItems = ref.read(groceryItemsProvider);
    final groceryList = ref.read(groceryListsProvider)
        .where((list) => list.id == widget.listId)
        .firstOrNull;
    
    if (groceryList != null) {
      final completedItems = allItems
          .where((item) => groceryList.itemIds.contains(item.id))
          .where((item) => item.isCompleted)
          .toList();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Clear Completed Items'),
          content: Text('Are you sure you want to delete ${completedItems.length} completed items?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                for (final item in completedItems) {
                  ref.read(groceryItemsProvider.notifier).deleteGroceryItem(item.id);
                  ref.read(groceryListsProvider.notifier)
                      .removeItemFromList(widget.listId, item.id);
                }
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${completedItems.length} completed items deleted')),
                );
              },
              child: const Text('Delete'),
            ),
          ],
        ),
      );
    }
  }
}

