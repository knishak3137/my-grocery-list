import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:intl/intl.dart';

import '../models/grocery_list.dart';
import '../providers/grocery_lists_provider.dart';
import '../providers/grocery_items_provider.dart';
import '../widgets/grocery_list_card.dart';
import 'list_detail_screen.dart';
import 'add_list_screen.dart';

class ScheduleScreen extends ConsumerStatefulWidget {
  const ScheduleScreen({super.key});

  @override
  ConsumerState<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends ConsumerState<ScheduleScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final groceryLists = ref.watch(groceryListsProvider);
    final groceryItems = ref.watch(groceryItemsProvider);

    final scheduledLists = groceryLists
        .where((list) => list.scheduledDate != null)
        .toList()
      ..sort((a, b) => a.scheduledDate!.compareTo(b.scheduledDate!));

    final todayLists = scheduledLists
        .where((list) => list.isScheduledToday)
        .toList();

    final tomorrowLists = scheduledLists
        .where((list) => list.isScheduledTomorrow)
        .toList();

    final upcomingLists = scheduledLists
        .where((list) => 
            !list.isScheduledToday && 
            !list.isScheduledTomorrow && 
            !list.isOverdue &&
            list.scheduledDate!.isAfter(DateTime.now()))
        .toList();

    final overdueLists = scheduledLists
        .where((list) => list.isOverdue)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Schedule'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: [
            Tab(
              text: 'Today',
              icon: Badge(
                isLabelVisible: todayLists.isNotEmpty,
                label: Text(todayLists.length.toString()),
                child: const Icon(Icons.today),
              ),
            ),
            Tab(
              text: 'Tomorrow',
              icon: Badge(
                isLabelVisible: tomorrowLists.isNotEmpty,
                label: Text(tomorrowLists.length.toString()),
                child: const Icon(Icons.tomorrow),
              ),
            ),
            Tab(
              text: 'Upcoming',
              icon: Badge(
                isLabelVisible: upcomingLists.isNotEmpty,
                label: Text(upcomingLists.length.toString()),
                child: const Icon(Icons.schedule),
              ),
            ),
            Tab(
              text: 'Overdue',
              icon: Badge(
                isLabelVisible: overdueLists.isNotEmpty,
                label: Text(overdueLists.length.toString()),
                child: const Icon(Icons.warning, color: Colors.red),
              ),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildScheduleTab(todayLists, groceryItems, 'today'),
          _buildScheduleTab(tomorrowLists, groceryItems, 'tomorrow'),
          _buildScheduleTab(upcomingLists, groceryItems, 'upcoming'),
          _buildScheduleTab(overdueLists, groceryItems, 'overdue'),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddListScreen(),
            ),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('New List'),
      ),
    );
  }

  Widget _buildScheduleTab(List<GroceryList> lists, List<dynamic> items, String type) {
    if (lists.isEmpty) {
      return _buildEmptyState(type);
    }

    return CustomScrollView(
      slivers: [
        if (type == 'today' || type == 'overdue') ...[
          SliverToBoxAdapter(
            child: Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: type == 'overdue' ? Colors.red.shade50 : Colors.green.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: type == 'overdue' ? Colors.red : Colors.green,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    type == 'overdue' ? Icons.warning : Icons.info,
                    color: type == 'overdue' ? Colors.red : Colors.green,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      type == 'overdue'
                          ? 'These lists are overdue. Consider rescheduling or completing them.'
                          : 'These lists are scheduled for today. Happy shopping!',
                      style: TextStyle(
                        color: type == 'overdue' ? Colors.red.shade700 : Colors.green.shade700,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                return AnimationConfiguration.staggeredList(
                  position: index,
                  duration: const Duration(milliseconds: 375),
                  child: SlideAnimation(
                    verticalOffset: 50.0,
                    child: FadeInAnimation(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _buildScheduledListCard(lists[index]),
                      ),
                    ),
                  ),
                );
              },
              childCount: lists.length,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildScheduledListCard(GroceryList list) {
    return Card(
      child: Column(
        children: [
          GroceryListCard(
            groceryList: list,
            onTap: () => _navigateToListDetail(list),
            onFavoriteToggle: () => _toggleFavorite(list.id),
            onDelete: () => _deleteList(list),
            onEdit: () => _editList(list),
          ),
          if (list.scheduledDate != null) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Icon(
                    Icons.access_time,
                    size: 16,
                    color: list.isOverdue 
                        ? Colors.red 
                        : Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Scheduled: ${DateFormat.yMMMd().add_jm().format(list.scheduledDate!)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: list.isOverdue 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => _rescheduleList(list),
                    child: const Text('Reschedule'),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildEmptyState(String type) {
    String title;
    String subtitle;
    IconData icon;

    switch (type) {
      case 'today':
        title = 'No Lists for Today';
        subtitle = 'Schedule some lists for today to see them here';
        icon = Icons.today;
        break;
      case 'tomorrow':
        title = 'No Lists for Tomorrow';
        subtitle = 'Schedule some lists for tomorrow to see them here';
        icon = Icons.tomorrow;
        break;
      case 'upcoming':
        title = 'No Upcoming Lists';
        subtitle = 'Schedule future shopping trips to see them here';
        icon = Icons.schedule;
        break;
      case 'overdue':
        title = 'No Overdue Lists';
        subtitle = 'Great! You\'re up to date with your shopping';
        icon = Icons.check_circle;
        break;
      default:
        title = 'No Scheduled Lists';
        subtitle = 'Schedule your shopping trips to see them here';
        icon = Icons.schedule;
    }

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(60),
              ),
              child: Icon(
                icon,
                size: 60,
                color: type == 'overdue' ? Colors.green : Colors.grey,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            if (type != 'overdue') ...[
              const SizedBox(height: 32),
              FilledButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const AddListScreen(),
                    ),
                  );
                },
                icon: const Icon(Icons.add),
                label: const Text('Create Scheduled List'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _navigateToListDetail(GroceryList list) {
    ref.read(selectedListProvider.notifier).state = list;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ListDetailScreen(listId: list.id),
      ),
    );
  }

  void _toggleFavorite(String listId) {
    ref.read(groceryListsProvider.notifier).toggleListFavorite(listId);
  }

  void _deleteList(GroceryList list) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete List'),
        content: Text('Are you sure you want to delete "${list.title}"? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              ref.read(groceryListsProvider.notifier).deleteGroceryList(list.id);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${list.title} deleted')),
              );
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _editList(GroceryList list) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddListScreen(editingList: list),
      ),
    );
  }

  void _rescheduleList(GroceryList list) async {
    final date = await showDatePicker(
      context: context,
      initialDate: list.scheduledDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (date != null && mounted) {
      final time = await showTimePicker(
        context: context,
        initialTime: list.scheduledDate != null 
            ? TimeOfDay.fromDateTime(list.scheduledDate!)
            : TimeOfDay.now(),
      );

      if (time != null && mounted) {
        final newScheduledDate = DateTime(
          date.year,
          date.month,
          date.day,
          time.hour,
          time.minute,
        );

        ref.read(groceryListsProvider.notifier)
            .updateListSchedule(list.id, newScheduledDate);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'List rescheduled to ${DateFormat.yMMMd().add_jm().format(newScheduledDate)}',
            ),
          ),
        );
      }
    }
  }
}

