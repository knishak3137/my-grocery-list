import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/grocery_item.dart';
import '../models/category.dart';
import '../providers/grocery_items_provider.dart';
import '../providers/grocery_lists_provider.dart';
import '../providers/categories_provider.dart';

class AddItemScreen extends ConsumerStatefulWidget {
  final String listId;
  final GroceryItem? editingItem;

  const AddItemScreen({
    super.key,
    required this.listId,
    this.editingItem,
  });

  @override
  ConsumerState<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends ConsumerState<AddItemScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _quantityController = TextEditingController();
  final _notesController = TextEditingController();
  final _priceController = TextEditingController();
  final _brandController = TextEditingController();

  String? _selectedCategoryId;
  bool _isImportant = false;

  @override
  void initState() {
    super.initState();
    if (widget.editingItem != null) {
      _nameController.text = widget.editingItem!.name;
      _quantityController.text = widget.editingItem!.quantity;
      _notesController.text = widget.editingItem!.notes;
      _priceController.text = widget.editingItem!.price?.toString() ?? '';
      _brandController.text = widget.editingItem!.brand ?? '';
      _selectedCategoryId = widget.editingItem!.categoryId;
      _isImportant = widget.editingItem!.isImportant;
    } else {
      _quantityController.text = '1';
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _quantityController.dispose();
    _notesController.dispose();
    _priceController.dispose();
    _brandController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider);
    final isEditing = widget.editingItem != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Item' : 'Add Item'),
        actions: [
          TextButton(
            onPressed: _saveItem,
            child: Text(
              isEditing ? 'Update' : 'Save',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // Item Name Field
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Item Name',
                      hintText: 'Enter item name',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.shopping_basket),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter an item name';
                      }
                      return null;
                    },
                    textCapitalization: TextCapitalization.words,
                    autofocus: !isEditing,
                  ),
                  const SizedBox(height: 16),

                  // Quantity Field
                  TextFormField(
                    controller: _quantityController,
                    decoration: const InputDecoration(
                      labelText: 'Quantity',
                      hintText: 'e.g., 2, 1 kg, 500ml',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.numbers),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter a quantity';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Category Dropdown
                  DropdownButtonFormField<String>(
                    value: _selectedCategoryId,
                    decoration: const InputDecoration(
                      labelText: 'Category',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.category),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please select a category';
                      }
                      return null;
                    },
                    items: categories.map((category) {
                      return DropdownMenuItem<String>(
                        value: category.id,
                        child: Row(
                          children: [
                            Text(
                              category.icon,
                              style: const TextStyle(fontSize: 20),
                            ),
                            const SizedBox(width: 8),
                            Text(category.name),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedCategoryId = value;
                      });
                    },
                  ),
                  const SizedBox(height: 16),

                  // Brand Field (Optional)
                  TextFormField(
                    controller: _brandController,
                    decoration: const InputDecoration(
                      labelText: 'Brand (Optional)',
                      hintText: 'Enter brand name',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.branding_watermark),
                    ),
                    textCapitalization: TextCapitalization.words,
                  ),
                  const SizedBox(height: 16),

                  // Price Field (Optional)
                  TextFormField(
                    controller: _priceController,
                    decoration: const InputDecoration(
                      labelText: 'Price (Optional)',
                      hintText: 'Enter price',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.attach_money),
                    ),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: (value) {
                      if (value != null && value.trim().isNotEmpty) {
                        final price = double.tryParse(value.trim());
                        if (price == null || price < 0) {
                          return 'Please enter a valid price';
                        }
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  // Notes Field
                  TextFormField(
                    controller: _notesController,
                    decoration: const InputDecoration(
                      labelText: 'Notes (Optional)',
                      hintText: 'Enter additional notes',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.note),
                    ),
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                  ),
                  const SizedBox(height: 24),

                  // Important Toggle
                  Card(
                    child: SwitchListTile(
                      title: const Text('Mark as Important'),
                      subtitle: const Text('Important items will be highlighted'),
                      value: _isImportant,
                      onChanged: (value) {
                        setState(() {
                          _isImportant = value;
                        });
                      },
                      secondary: Icon(
                        _isImportant ? Icons.star : Icons.star_border,
                        color: _isImportant ? Colors.orange : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Quick Add Suggestions (for new items only)
                  if (!isEditing) ...[
                    Text(
                      'Quick Add Suggestions',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildQuickAddSuggestions(),
                    const SizedBox(height: 32),
                  ],
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAddSuggestions() {
    final suggestions = [
      {'name': 'Milk', 'category': 'dairy', 'quantity': '1 gallon'},
      {'name': 'Bread', 'category': 'bakery', 'quantity': '1 loaf'},
      {'name': 'Eggs', 'category': 'dairy', 'quantity': '1 dozen'},
      {'name': 'Bananas', 'category': 'fruits', 'quantity': '1 bunch'},
      {'name': 'Chicken Breast', 'category': 'meat', 'quantity': '1 lb'},
      {'name': 'Rice', 'category': 'food_grocery', 'quantity': '1 bag'},
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: suggestions.map((suggestion) {
        return ActionChip(
          label: Text(suggestion['name']!),
          onPressed: () {
            _nameController.text = suggestion['name']!;
            _quantityController.text = suggestion['quantity']!;
            _selectedCategoryId = suggestion['category']!;
            setState(() {});
          },
        );
      }).toList(),
    );
  }

  void _saveItem() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final isEditing = widget.editingItem != null;
    double? price;
    
    if (_priceController.text.trim().isNotEmpty) {
      price = double.tryParse(_priceController.text.trim());
    }

    final groceryItem = isEditing
        ? widget.editingItem!.copyWith(
            name: _nameController.text.trim(),
            quantity: _quantityController.text.trim(),
            categoryId: _selectedCategoryId!,
            notes: _notesController.text.trim(),
            price: price,
            brand: _brandController.text.trim().isEmpty 
                ? null 
                : _brandController.text.trim(),
            isImportant: _isImportant,
            updatedAt: DateTime.now(),
          )
        : GroceryItem.create(
            name: _nameController.text.trim(),
            quantity: _quantityController.text.trim(),
            categoryId: _selectedCategoryId!,
            notes: _notesController.text.trim(),
            price: price,
            brand: _brandController.text.trim().isEmpty 
                ? null 
                : _brandController.text.trim(),
            isImportant: _isImportant,
          );

    if (isEditing) {
      ref.read(groceryItemsProvider.notifier).updateGroceryItem(groceryItem);
    } else {
      ref.read(groceryItemsProvider.notifier).addGroceryItem(groceryItem);
      ref.read(groceryListsProvider.notifier).addItemToList(widget.listId, groceryItem.id);
    }

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isEditing 
            ? 'Item updated successfully' 
            : 'Item added successfully'),
      ),
    );
  }
}

