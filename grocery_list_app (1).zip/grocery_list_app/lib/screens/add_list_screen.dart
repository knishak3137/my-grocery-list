import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../models/grocery_list.dart';
import '../providers/grocery_lists_provider.dart';

class AddListScreen extends ConsumerStatefulWidget {
  final GroceryList? editingList;

  const AddListScreen({super.key, this.editingList});

  @override
  ConsumerState<AddListScreen> createState() => _AddListScreenState();
}

class _AddListScreenState extends ConsumerState<AddListScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _notesController = TextEditingController();
  
  DateTime? _scheduledDate;
  int _selectedColor = 0xFF4CAF50;
  bool _isFavorite = false;

  final List<int> _colorOptions = [
    0xFF4CAF50, // Green
    0xFF2196F3, // Blue
    0xFFFF9800, // Orange
    0xFFE91E63, // Pink
    0xFF9C27B0, // Purple
    0xFF00BCD4, // Cyan
    0xFFFF5722, // Deep Orange
    0xFF795548, // Brown
    0xFF607D8B, // Blue Grey
    0xFFF44336, // Red
  ];

  @override
  void initState() {
    super.initState();
    if (widget.editingList != null) {
      _titleController.text = widget.editingList!.title;
      _descriptionController.text = widget.editingList!.description;
      _notesController.text = widget.editingList!.notes ?? '';
      _scheduledDate = widget.editingList!.scheduledDate;
      _selectedColor = widget.editingList!.color;
      _isFavorite = widget.editingList!.isFavorite;
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.editingList != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Edit List' : 'New List'),
        actions: [
          TextButton(
            onPressed: _saveList,
            child: Text(
              isEditing ? 'Update' : 'Save',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  // Title Field
                  TextFormField(
                    controller: _titleController,
                    decoration: const InputDecoration(
                      labelText: 'List Title',
                      hintText: 'Enter list title',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.title),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter a list title';
                      }
                      return null;
                    },
                    textCapitalization: TextCapitalization.words,
                  ),
                  const SizedBox(height: 16),

                  // Description Field
                  TextFormField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description (Optional)',
                      hintText: 'Enter list description',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.description),
                    ),
                    maxLines: 2,
                    textCapitalization: TextCapitalization.sentences,
                  ),
                  const SizedBox(height: 16),

                  // Notes Field
                  TextFormField(
                    controller: _notesController,
                    decoration: const InputDecoration(
                      labelText: 'Notes (Optional)',
                      hintText: 'Enter additional notes',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.note),
                    ),
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                  ),
                  const SizedBox(height: 24),

                  // Schedule Section
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.schedule),
                              const SizedBox(width: 8),
                              Text(
                                'Schedule',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ListTile(
                            title: Text(_scheduledDate == null 
                                ? 'No schedule set' 
                                : DateFormat.yMMMd().add_jm().format(_scheduledDate!)),
                            subtitle: const Text('Tap to set shopping date and time'),
                            leading: const Icon(Icons.calendar_today),
                            trailing: _scheduledDate != null 
                                ? IconButton(
                                    icon: const Icon(Icons.clear),
                                    onPressed: () {
                                      setState(() {
                                        _scheduledDate = null;
                                      });
                                    },
                                  )
                                : null,
                            onTap: _selectDateTime,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Color Selection
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.palette),
                              const SizedBox(width: 8),
                              Text(
                                'Color',
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _colorOptions.map((color) {
                              final isSelected = color == _selectedColor;
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _selectedColor = color;
                                  });
                                },
                                child: Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: Color(color),
                                    shape: BoxShape.circle,
                                    border: isSelected
                                        ? Border.all(
                                            color: Theme.of(context).colorScheme.primary,
                                            width: 3,
                                          )
                                        : null,
                                  ),
                                  child: isSelected
                                      ? const Icon(
                                          Icons.check,
                                          color: Colors.white,
                                          size: 20,
                                        )
                                      : null,
                                ),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Favorite Toggle
                  Card(
                    child: SwitchListTile(
                      title: const Text('Add to Favorites'),
                      subtitle: const Text('Mark this list as a favorite'),
                      value: _isFavorite,
                      onChanged: (value) {
                        setState(() {
                          _isFavorite = value;
                        });
                      },
                      secondary: Icon(
                        _isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: _isFavorite ? Colors.red : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _scheduledDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (date != null && mounted) {
      final time = await showTimePicker(
        context: context,
        initialTime: _scheduledDate != null 
            ? TimeOfDay.fromDateTime(_scheduledDate!)
            : TimeOfDay.now(),
      );

      if (time != null && mounted) {
        setState(() {
          _scheduledDate = DateTime(
            date.year,
            date.month,
            date.day,
            time.hour,
            time.minute,
          );
        });
      }
    }
  }

  void _saveList() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    final isEditing = widget.editingList != null;
    final groceryList = isEditing
        ? widget.editingList!.copyWith(
            title: _titleController.text.trim(),
            description: _descriptionController.text.trim(),
            notes: _notesController.text.trim().isEmpty 
                ? null 
                : _notesController.text.trim(),
            scheduledDate: _scheduledDate,
            color: _selectedColor,
            isFavorite: _isFavorite,
            updatedAt: DateTime.now(),
          )
        : GroceryList.create(
            title: _titleController.text.trim(),
            description: _descriptionController.text.trim(),
            scheduledDate: _scheduledDate,
            color: _selectedColor,
            notes: _notesController.text.trim().isEmpty 
                ? null 
                : _notesController.text.trim(),
          ).copyWith(isFavorite: _isFavorite);

    if (isEditing) {
      ref.read(groceryListsProvider.notifier).updateGroceryList(groceryList);
    } else {
      ref.read(groceryListsProvider.notifier).addGroceryList(groceryList);
    }

    Navigator.pop(context);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isEditing 
            ? 'List updated successfully' 
            : 'List created successfully'),
      ),
    );
  }
}

