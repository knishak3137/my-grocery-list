import 'package:hive_flutter/hive_flutter.dart';
import '../models/grocery_item.dart';
import '../models/grocery_list.dart';
import '../models/category.dart';

class DatabaseService {
  static const String _groceryItemsBox = 'grocery_items';
  static const String _groceryListsBox = 'grocery_lists';
  static const String _categoriesBox = 'categories';
  static const String _settingsBox = 'settings';

  static DatabaseService? _instance;
  static DatabaseService get instance => _instance ??= DatabaseService._();
  
  DatabaseService._();

  late Box<GroceryItem> _groceryItemsBox_;
  late Box<GroceryList> _groceryListsBox_;
  late Box<Category> _categoriesBox_;
  late Box<dynamic> _settingsBox_;

  // Initialize database
  Future<void> init() async {
    _groceryItemsBox_ = await Hive.openBox<GroceryItem>(_groceryItemsBox);
    _groceryListsBox_ = await Hive.openBox<GroceryList>(_groceryListsBox);
    _categoriesBox_ = await Hive.openBox<Category>(_categoriesBox);
    _settingsBox_ = await Hive.openBox(_settingsBox);

    // Initialize default categories if empty
    if (_categoriesBox_.isEmpty) {
      await _initializeDefaultCategories();
    }
  }

  // Initialize default categories
  Future<void> _initializeDefaultCategories() async {
    for (final category in Category.defaultCategories) {
      await _categoriesBox_.put(category.id, category);
    }
  }

  // Grocery Items CRUD operations
  Future<void> saveGroceryItem(GroceryItem item) async {
    await _groceryItemsBox_.put(item.id, item);
  }

  Future<void> deleteGroceryItem(String id) async {
    await _groceryItemsBox_.delete(id);
  }

  GroceryItem? getGroceryItem(String id) {
    return _groceryItemsBox_.get(id);
  }

  List<GroceryItem> getAllGroceryItems() {
    return _groceryItemsBox_.values.toList();
  }

  List<GroceryItem> getGroceryItemsByIds(List<String> ids) {
    return ids
        .map((id) => _groceryItemsBox_.get(id))
        .where((item) => item != null)
        .cast<GroceryItem>()
        .toList();
  }

  List<GroceryItem> searchGroceryItems(String query) {
    if (query.trim().isEmpty) return getAllGroceryItems();
    
    final lowercaseQuery = query.toLowerCase();
    return _groceryItemsBox_.values
        .where((item) =>
            item.name.toLowerCase().contains(lowercaseQuery) ||
            item.notes.toLowerCase().contains(lowercaseQuery) ||
            (item.brand?.toLowerCase().contains(lowercaseQuery) ?? false))
        .toList();
  }

  List<GroceryItem> filterGroceryItems({
    bool? isCompleted,
    bool? isImportant,
    String? categoryId,
  }) {
    return _groceryItemsBox_.values.where((item) {
      if (isCompleted != null && item.isCompleted != isCompleted) return false;
      if (isImportant != null && item.isImportant != isImportant) return false;
      if (categoryId != null && item.categoryId != categoryId) return false;
      return true;
    }).toList();
  }

  // Grocery Lists CRUD operations
  Future<void> saveGroceryList(GroceryList list) async {
    await _groceryListsBox_.put(list.id, list);
  }

  Future<void> deleteGroceryList(String id) async {
    // Also delete all items in this list
    final list = _groceryListsBox_.get(id);
    if (list != null) {
      for (final itemId in list.itemIds) {
        await deleteGroceryItem(itemId);
      }
    }
    await _groceryListsBox_.delete(id);
  }

  GroceryList? getGroceryList(String id) {
    return _groceryListsBox_.get(id);
  }

  List<GroceryList> getAllGroceryLists() {
    return _groceryListsBox_.values.toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  List<GroceryList> searchGroceryLists(String query) {
    if (query.trim().isEmpty) return getAllGroceryLists();
    
    final lowercaseQuery = query.toLowerCase();
    return _groceryListsBox_.values
        .where((list) =>
            list.title.toLowerCase().contains(lowercaseQuery) ||
            list.description.toLowerCase().contains(lowercaseQuery) ||
            (list.notes?.toLowerCase().contains(lowercaseQuery) ?? false))
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  List<GroceryList> getScheduledLists() {
    return _groceryListsBox_.values
        .where((list) => list.scheduledDate != null)
        .toList()
      ..sort((a, b) => a.scheduledDate!.compareTo(b.scheduledDate!));
  }

  List<GroceryList> getFavoriteLists() {
    return _groceryListsBox_.values
        .where((list) => list.isFavorite)
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  // Categories CRUD operations
  Future<void> saveCategory(Category category) async {
    await _categoriesBox_.put(category.id, category);
  }

  Future<void> deleteCategory(String id) async {
    // Don't allow deletion of default categories
    final defaultIds = Category.defaultCategories.map((c) => c.id).toSet();
    if (defaultIds.contains(id)) return;
    
    await _categoriesBox_.delete(id);
  }

  Category? getCategory(String id) {
    return _categoriesBox_.get(id);
  }

  List<Category> getAllCategories() {
    return _categoriesBox_.values.toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  // Settings operations
  Future<void> saveSetting(String key, dynamic value) async {
    await _settingsBox_.put(key, value);
  }

  T? getSetting<T>(String key, [T? defaultValue]) {
    return _settingsBox_.get(key, defaultValue: defaultValue) as T?;
  }

  Future<void> deleteSetting(String key) async {
    await _settingsBox_.delete(key);
  }

  // Statistics
  Map<String, int> getCategoryStatistics() {
    final items = getAllGroceryItems();
    final categories = getAllCategories();
    final stats = <String, int>{};
    
    for (final category in categories) {
      stats[category.name] = items.where((item) => item.categoryId == category.id).length;
    }
    
    return stats;
  }

  Map<String, int> getCompletionStatistics() {
    final items = getAllGroceryItems();
    return {
      'total': items.length,
      'completed': items.where((item) => item.isCompleted).length,
      'pending': items.where((item) => !item.isCompleted).length,
      'important': items.where((item) => item.isImportant).length,
    };
  }

  List<String> getMostUsedItems({int limit = 10}) {
    final items = getAllGroceryItems();
    final itemCounts = <String, int>{};
    
    for (final item in items) {
      itemCounts[item.name] = (itemCounts[item.name] ?? 0) + 1;
    }
    
    final sortedItems = itemCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    return sortedItems.take(limit).map((e) => e.key).toList();
  }

  // Backup and Restore
  Future<Map<String, dynamic>> exportData() async {
    return {
      'grocery_items': _groceryItemsBox_.values.map((item) => item.toJson()).toList(),
      'grocery_lists': _groceryListsBox_.values.map((list) => list.toJson()).toList(),
      'categories': _categoriesBox_.values.map((category) => category.toJson()).toList(),
      'settings': Map<String, dynamic>.from(_settingsBox_.toMap()),
      'export_date': DateTime.now().toIso8601String(),
      'version': '1.0.0',
    };
  }

  Future<bool> importData(Map<String, dynamic> data) async {
    try {
      // Clear existing data
      await _groceryItemsBox_.clear();
      await _groceryListsBox_.clear();
      await _categoriesBox_.clear();
      await _settingsBox_.clear();

      // Import grocery items
      if (data['grocery_items'] != null) {
        for (final itemJson in data['grocery_items']) {
          final item = GroceryItem.fromJson(itemJson);
          await saveGroceryItem(item);
        }
      }

      // Import grocery lists
      if (data['grocery_lists'] != null) {
        for (final listJson in data['grocery_lists']) {
          final list = GroceryList.fromJson(listJson);
          await saveGroceryList(list);
        }
      }

      // Import categories
      if (data['categories'] != null) {
        for (final categoryJson in data['categories']) {
          final category = Category.fromJson(categoryJson);
          await saveCategory(category);
        }
      } else {
        // Initialize default categories if none provided
        await _initializeDefaultCategories();
      }

      // Import settings
      if (data['settings'] != null) {
        for (final entry in data['settings'].entries) {
          await saveSetting(entry.key, entry.value);
        }
      }

      return true;
    } catch (e) {
      // If import fails, reinitialize default categories
      await _initializeDefaultCategories();
      return false;
    }
  }

  // Reset all data
  Future<void> resetAllData() async {
    await _groceryItemsBox_.clear();
    await _groceryListsBox_.clear();
    await _categoriesBox_.clear();
    await _settingsBox_.clear();
    
    // Reinitialize default categories
    await _initializeDefaultCategories();
  }

  // Close database
  Future<void> close() async {
    await _groceryItemsBox_.close();
    await _groceryListsBox_.close();
    await _categoriesBox_.close();
    await _settingsBox_.close();
  }
}


  // Export all data to a Map for JSON serialization
  Future<Map<String, dynamic>> exportData() async {
    final groceryLists = getAllGroceryLists();
    final groceryItems = getAllGroceryItems();
    final categories = getAllCategories();

    return {
      'version': '1.0.0',
      'exportDate': DateTime.now().toIso8601String(),
      'data': {
        'groceryLists': groceryLists.map((list) => list.toJson()).toList(),
        'groceryItems': groceryItems.map((item) => item.toJson()).toList(),
        'categories': categories.map((category) => category.toJson()).toList(),
      },
    };
  }

  // Import data from a Map (parsed from JSON)
  Future<bool> importData(Map<String, dynamic> data) async {
    try {
      // Clear existing data
      await resetAllData();

      final importData = data['data'] as Map<String, dynamic>;

      // Import categories first
      if (importData.containsKey('categories')) {
        final categoriesData = importData['categories'] as List;
        for (final categoryData in categoriesData) {
          final category = Category.fromJson(categoryData);
          await addCategory(category);
        }
      }

      // Import grocery lists
      if (importData.containsKey('groceryLists')) {
        final listsData = importData['groceryLists'] as List;
        for (final listData in listsData) {
          final groceryList = GroceryList.fromJson(listData);
          await addGroceryList(groceryList);
        }
      }

      // Import grocery items
      if (importData.containsKey('groceryItems')) {
        final itemsData = importData['groceryItems'] as List;
        for (final itemData in itemsData) {
          final groceryItem = GroceryItem.fromJson(itemData);
          await addGroceryItem(groceryItem);
        }
      }

      return true;
    } catch (e) {
      print('Error importing data: $e');
      return false;
    }
  }

  // Reset all data
  Future<void> resetAllData() async {
    await _groceryListsBox.clear();
    await _groceryItemsBox.clear();
    await _categoriesBox.clear();
    
    // Re-initialize with default categories
    await _initializeDefaultCategories();
  }
}

